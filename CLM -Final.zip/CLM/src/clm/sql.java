/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clm;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class sql {
    
   public String url = "jdbc:mysql://localhost:3306/clm?zeroDateTimeBehavior=CONVERT_TO_NULL";
     public    String user = "root";
    public    String password = "";
    public    Connection connection = null;
 List<String> resultList = new ArrayList<>();

    public sql() throws ClassNotFoundException{
    Class.forName("com.mysql.cj.jdbc.Driver");
   
    try{
   Connection connection = DriverManager.getConnection(url, user, password);
System.out.println("goods");

    }catch(Exception e){
    
    
    
    }
    
    
    }
    
    
}