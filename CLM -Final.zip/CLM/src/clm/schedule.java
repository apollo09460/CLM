/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package clm;

import static clm.user_info.selected;
import com.formdev.flatlaf.FlatLightLaf;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Calendar;
import java.util.Date;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author von
 */
public class schedule extends javax.swing.JFrame {

    /**
     * Creates new form schedule
     */
    
  
    public schedule(String Order) {
        initComponents();
        System.out.println(Order);
        this.Ordernum = Order;
         yawa = new user_info(Order);
yawa.setVisible(true);

     LocalDate currentDate = LocalDate.now();
            Calendar minDate = Calendar.getInstance();
        minDate.setTime(java.sql.Date.valueOf(currentDate));
         date.setMinSelectableDate(minDate.getTime());

    
        
        
    }
    
    public void sched(){
        
   
     
        yawa.dispose();
       System.out.println(Ordernum);
         try{
     
       Class.forName("com.mysql.cj.jdbc.Driver");
         String url = "jdbc:mysql://localhost:3306/clm?zeroDateTimeBehavior=CONVERT_TO_NULL";
         String user = "root";
        String password = "";
        Connection conn = DriverManager.getConnection(url,user,password);
      String sql =  "UPDATE work_order SET Time_Window = ?, Schedule_Date = ? WHERE WO_number = ?;";
      //DATE VALUES
       Date selected_date = date.getDate();
                  SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                String d = sdf.format(selected_date);
                // Time values
               String t = tw.getSelectedItem().toString();
              //
              
          //assign values
           PreparedStatement pst= conn.prepareStatement(sql);
           pst.setString(1, t);
                pst.setString(2, d);
                     pst.setString(3, Ordernum);
                
      
   
    
    
      pst.executeUpdate();
     
 
      
     
     
     
     }catch(Exception e){
     System.out.println(e);
     
     } 
         
         dispose();
   user_info newf = new user_info(Ordernum);
    newf.setVisible(rootPaneCheckingEnabled);
    
    
    }
    
    public void addlog(){
        user_info us = new user_info(Ordernum);
       
       LocalDate currentDate = LocalDate.now();
           LocalTime currentTime = LocalTime.now();
              Date selected_date = date.getDate();
                  SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                String d = sdf.format(selected_date);
           
        try{
          Class.forName("com.mysql.cj.jdbc.Driver");
         String url = "jdbc:mysql://localhost:3306/clm?zeroDateTimeBehavior=CONVERT_TO_NULL";
         String user = "root";
        String password = "";
        Connection conn = DriverManager.getConnection(url,user,password);
        String sql = "INSERT into com_log(WO_number,Logs,Date)VALUES(?,?,?)";
         PreparedStatement pst= conn.prepareStatement(sql);
         pst.setString(1, Ordernum);
         pst.setString(2, "Scheduled on "+ d);
           pst.setString(3, currentDate.toString());
         pst.executeUpdate();
               
      
          
        }
        
        catch(Exception e){
        
        System.out.println(e);
         
        }
    
    
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        date = new com.toedter.calendar.JDateChooser();
        tw = new javax.swing.JComboBox<>();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("Schedule Date:");

        jLabel2.setText("Time Window:");

        date.setBackground(new java.awt.Color(255, 102, 0));

        tw.setBackground(new java.awt.Color(204, 204, 204));
        tw.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "8:00am to 11:00am", "11:00 to 3:00pm", "3:00 to 7:00pm" }));
        tw.setBorder(null);

        jButton1.setText("Confirm");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("Cancel");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(41, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1)
                            .addComponent(jLabel2))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(date, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(tw, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(36, 36, 36)
                        .addComponent(jButton1)
                        .addGap(29, 29, 29)
                        .addComponent(jButton2)))
                .addGap(25, 25, 25))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(56, 56, 56)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(date, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(tw, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(46, 46, 46)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(jButton2))
                .addContainerGap(33, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        dispose();
      
    
     
        
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
       

       sched();
     
addlog();
   
        
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
       
        
               
        
try {
            // Set FlatLaf look and feel
            UIManager.setLookAndFeel(new FlatLightLaf()); // or FlatDarkLaf() for dark theme
        } catch (UnsupportedLookAndFeelException e) {
            e.printStackTrace();
        }
      

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new schedule(Order).setVisible(true);
            }
        });
    }
     
   public String Ordernum;
      public  user_info yawa = new user_info(Order);
public static String Order;
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private com.toedter.calendar.JDateChooser date;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JComboBox<String> tw;
    // End of variables declaration//GEN-END:variables
}
