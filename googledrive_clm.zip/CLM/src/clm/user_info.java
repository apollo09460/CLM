/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package clm;

import java.time.LocalDate;

  import java.time.LocalTime;
import static clm.search.tb;
import com.formdev.flatlaf.FlatLightLaf;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.ComponentOrientation;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author von
 */
public class user_info extends javax.swing.JFrame {

    /**
     * Creates new form user_info
     */
    public  void WOinfo(String selected){
        
        this.order = selected;
             String ord = selected;
      try{
     
       Class.forName("com.mysql.cj.jdbc.Driver");
         String url = "jdbc:mysql://localhost:3306/clm?zeroDateTimeBehavior=CONVERT_TO_NULL";
         String user = "root";
        String password = "";
        Connection conn = DriverManager.getConnection(url,user,password);
        String sql =  "SELECT * FROM work_order WHERE WO_number = ?";

       PreparedStatement pst= conn.prepareStatement(sql);
       pst.setString(1,ord);
      ResultSet rs = pst.executeQuery();
      
     if(rs.next()){
      String f = rs.getString("Customer_name");
     fulln.setText(rs.getString("Customer_name"));
      add.setText(rs.getString("address"));
      number.setText(rs.getString("Phone_number"));
      String status = rs.getString("Status");
      receive.setText(status);
      tw.setText(rs.getString("Time_Window"));
      sd.setText(rs.getString("Schedule_Date"));
      String det = rs.getString("Schedule_Date");
      
     rcd.setText(rs.getString("Receive_Date"));
      if("Not Received".equals(status)){
      receive.setForeground(Color.red);
       ready.setText("Not Ready to Schedule");
       ready.setForeground(Color.red);
      }
      if(!det.isEmpty()){
      System.out.println(det);
       System.out.println("has date");
       ready.setText("Date Scheduled");
       ready.setForeground(Color.GREEN);
      
      }
      
      
       
    
      }
     
    
     
     }catch(Exception e){
     
     
     }
    
    }
    public void getprod(){
       DefaultTableModel model = (DefaultTableModel)prod.getModel();
 model.setRowCount(0);
  DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
centerRenderer.setHorizontalAlignment(SwingConstants.CENTER);
 prod.setDefaultRenderer(Object.class, centerRenderer);
 
 
     try{
         
            Class.forName("com.mysql.cj.jdbc.Driver");
         String url = "jdbc:mysql://localhost:3306/clm?zeroDateTimeBehavior=CONVERT_TO_NULL";
         String user = "root";
        String password = "";
        Connection conn = DriverManager.getConnection(url,user,password);
        String sql =  "SELECT * FROM prod WHERE WO_number = ? ";

       PreparedStatement pst= conn.prepareStatement(sql);
      pst.setString(1,order);
      ResultSet rs = pst.executeQuery();
   
       while(rs.next()){
         
       String log = rs.getString("Vendor");
       String Date = rs.getString("Product");
           String list[] = {log  , Date };
               model.addRow(list);
             
       
       
       }
       
       }  catch (Exception e){
       System.out.println(e);
       
       
       }
    
    
        
        
    
    
    }
  
    
    public void getlog(){
     DefaultTableModel model = (DefaultTableModel)logT.getModel();
 model.setRowCount(0);
 logT.setRowHeight(40);
 
 DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
centerRenderer.setHorizontalAlignment(SwingConstants.CENTER);
 logT.setDefaultRenderer(Object.class, centerRenderer);
 

       try{
         
            Class.forName("com.mysql.cj.jdbc.Driver");
         String url = "jdbc:mysql://localhost:3306/clm?zeroDateTimeBehavior=CONVERT_TO_NULL";
         String user = "root";
        String password = "";
        Connection conn = DriverManager.getConnection(url,user,password);
        String sql =  "SELECT * FROM com_log WHERE WO_number = ? ";

       PreparedStatement pst= conn.prepareStatement(sql);
      pst.setString(1,order);
      ResultSet rs = pst.executeQuery();
   
       while(rs.next()){
         
       String log = rs.getString("Logs");
       String Date = rs.getString("Date");
           String list[] = {log  , Date };
               model.addRow(list);
             
       
       
       }
       
       }  catch (Exception e){
       System.out.println(e);
       
       
       }
       
    
    
    }
    
    
        public  user_info(String selected) {

                    this.order = selected;

       
       
       initComponents();
       
      getlog();
      WOinfo(selected);
       getprod();
       
    String ord = selected;
              
     
        
          
          try{
          
             Class.forName("com.mysql.cj.jdbc.Driver");
         String url = "jdbc:mysql://localhost:3306/clm?zeroDateTimeBehavior=CONVERT_TO_NULL";
         String user = "root";
        String password = "";
        Connection conn = DriverManager.getConnection(url,user,password);
        String sql =  "SELECT * FROM hub";

       PreparedStatement pst= conn.prepareStatement(sql);
      
      ResultSet rs = pst.executeQuery();
      
      if(rs.next()){
      String type = rs.getString("Location Type");
        String facility = rs.getString("Facility");
          String hubad = rs.getString("Address");
            String num = rs.getString("Phone_number");
            loc.setText(type);
      fac.setText(facility);
      hubadd.setText(hubad);
      hubn.setText(num);
      }
      
      
          
          }
          
          catch(Exception e){}
     
          
        
    }

  

 

    
   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        delivery = new javax.swing.JTabbedPane();
        delivery_tab = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jPanel5 = new javax.swing.JPanel();
        jPanel7 = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        jPanel8 = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        hubn = new javax.swing.JLabel();
        loc = new javax.swing.JLabel();
        fac = new javax.swing.JLabel();
        hubadd = new javax.swing.JLabel();
        number = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        add = new javax.swing.JLabel();
        FirstN = new javax.swing.JLabel();
        jPanel9 = new javax.swing.JPanel();
        jLabel21 = new javax.swing.JLabel();
        sd = new javax.swing.JLabel();
        tw = new javax.swing.JLabel();
        rcd = new javax.swing.JLabel();
        fulln = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        jLabel29 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        logT = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        comtext = new javax.swing.JTextArea();
        jPanel4 = new javax.swing.JPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        prod = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        stat = new javax.swing.JLabel();
        receive = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        ready = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        OA = new javax.swing.JComboBox<>();
        jButton2 = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 102, 51));
        setForeground(new java.awt.Color(255, 51, 204));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        delivery_tab.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jScrollPane2.setBackground(new java.awt.Color(204, 255, 0));

        jPanel5.setBackground(new java.awt.Color(255, 255, 255));
        jPanel5.setPreferredSize(new java.awt.Dimension(802, 396));
        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel11.setText("Scheduled Date");

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(116, Short.MAX_VALUE))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel11)
                .addContainerGap(8, Short.MAX_VALUE))
        );

        jPanel5.add(jPanel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 210, 270, 30));

        jLabel12.setText("Destination");

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(132, Short.MAX_VALUE))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createSequentialGroup()
                .addContainerGap(8, Short.MAX_VALUE)
                .addComponent(jLabel12)
                .addContainerGap())
        );

        jPanel5.add(jPanel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 60, 250, 30));

        hubn.setFont(new java.awt.Font("sansserif", 0, 10)); // NOI18N
        hubn.setText("Phone number:");
        jPanel5.add(hubn, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 160, -1, -1));

        loc.setFont(new java.awt.Font("sansserif", 0, 10)); // NOI18N
        loc.setText("location type");
        jPanel5.add(loc, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 100, -1, -1));

        fac.setFont(new java.awt.Font("sansserif", 0, 10)); // NOI18N
        fac.setText("Facility:");
        jPanel5.add(fac, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 120, -1, -1));

        hubadd.setFont(new java.awt.Font("sansserif", 0, 10)); // NOI18N
        hubadd.setText("Address:");
        jPanel5.add(hubadd, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 140, -1, -1));

        number.setFont(new java.awt.Font("sansserif", 0, 10)); // NOI18N
        number.setText("Phone number:");
        jPanel5.add(number, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 160, -1, -1));

        jLabel18.setFont(new java.awt.Font("sansserif", 0, 10)); // NOI18N
        jLabel18.setText("Email:");
        jPanel5.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 140, -1, -1));

        add.setFont(new java.awt.Font("sansserif", 0, 10)); // NOI18N
        add.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        add.setText("Add");
        jPanel5.add(add, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 120, 330, 20));

        FirstN.setFont(new java.awt.Font("sansserif", 0, 10)); // NOI18N
        jPanel5.add(FirstN, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 100, -1, -1));

        jLabel21.setText("Origin");

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(216, Short.MAX_VALUE))
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel21)
                .addContainerGap(8, Short.MAX_VALUE))
        );

        jPanel5.add(jPanel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 60, 270, 30));

        sd.setFont(new java.awt.Font("sansserif", 0, 10)); // NOI18N
        sd.setText("__________");
        jPanel5.add(sd, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 290, -1, -1));

        tw.setFont(new java.awt.Font("sansserif", 0, 10)); // NOI18N
        tw.setText("__________");
        jPanel5.add(tw, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 270, -1, -1));

        rcd.setFont(new java.awt.Font("sansserif", 0, 10)); // NOI18N
        rcd.setText("Received date:");
        jPanel5.add(rcd, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 250, -1, -1));

        fulln.setFont(new java.awt.Font("sansserif", 0, 10)); // NOI18N
        fulln.setText("Name:");
        jPanel5.add(fulln, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 100, -1, -1));

        jLabel26.setFont(new java.awt.Font("sansserif", 0, 10)); // NOI18N
        jLabel26.setText("Name:");
        jPanel5.add(jLabel26, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 100, -1, -1));

        jLabel20.setFont(new java.awt.Font("sansserif", 0, 10)); // NOI18N
        jLabel20.setText("Address:");
        jPanel5.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 120, -1, -1));

        jLabel22.setFont(new java.awt.Font("sansserif", 0, 10)); // NOI18N
        jLabel22.setText("Phone number:");
        jPanel5.add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 160, -1, -1));

        jLabel27.setFont(new java.awt.Font("sansserif", 0, 10)); // NOI18N
        jLabel27.setText("Received date:");
        jPanel5.add(jLabel27, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 250, -1, -1));

        jLabel28.setFont(new java.awt.Font("sansserif", 0, 10)); // NOI18N
        jLabel28.setText("Time window:");
        jPanel5.add(jLabel28, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 270, -1, -1));

        jLabel29.setFont(new java.awt.Font("sansserif", 0, 10)); // NOI18N
        jLabel29.setText("Scheduled date:");
        jPanel5.add(jLabel29, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 290, -1, -1));

        jLabel17.setFont(new java.awt.Font("sansserif", 0, 10)); // NOI18N
        jLabel17.setText("Location Type:");
        jPanel5.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 100, -1, -1));

        jLabel19.setFont(new java.awt.Font("sansserif", 0, 10)); // NOI18N
        jLabel19.setText("Facility:");
        jPanel5.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 120, -1, -1));

        jLabel23.setFont(new java.awt.Font("sansserif", 0, 10)); // NOI18N
        jLabel23.setText("Address:");
        jPanel5.add(jLabel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 140, -1, -1));

        jLabel24.setFont(new java.awt.Font("sansserif", 0, 10)); // NOI18N
        jLabel24.setText("Phone number:");
        jPanel5.add(jLabel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 160, -1, -1));

        jScrollPane2.setViewportView(jPanel5);

        delivery_tab.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 750, 320));

        delivery.addTab("Delivery", delivery_tab);

        logT.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "Logs", "Date"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(logT);

        jButton1.setText("Save");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        comtext.setColumns(20);
        comtext.setRows(5);
        jScrollPane3.setViewportView(comtext);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(45, 45, 45)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 265, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton1)
                        .addGap(16, 16, 16)))
                .addGap(67, 67, 67)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 407, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jButton1)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 323, Short.MAX_VALUE))
                .addContainerGap())
        );

        delivery.addTab("Communication log", jPanel3);

        prod.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "Vendor", "Product "
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane4.setViewportView(prod);

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 778, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 319, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(10, Short.MAX_VALUE))
        );

        delivery.addTab("Product", jPanel4);

        jPanel2.add(delivery, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 100, 790, 370));

        jLabel1.setFont(new java.awt.Font("sansserif", 0, 10)); // NOI18N
        jLabel1.setText("Operational Status");
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 10, -1, -1));

        jLabel2.setFont(new java.awt.Font("sansserif", 0, 10)); // NOI18N
        jLabel2.setText("Order Category ");
        jPanel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 10, -1, -1));

        jLabel3.setFont(new java.awt.Font("sansserif", 0, 10)); // NOI18N
        jLabel3.setText("Work Order Status");
        jPanel2.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 10, -1, -1));

        stat.setFont(new java.awt.Font("sansserif", 0, 10)); // NOI18N
        stat.setText("Receiving Status");
        jPanel2.add(stat, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 10, -1, -1));

        receive.setFont(new java.awt.Font("sansserif", 1, 12)); // NOI18N
        receive.setForeground(new java.awt.Color(51, 255, 51));
        receive.setText("Fully Received");
        jPanel2.add(receive, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 30, -1, -1));

        jLabel6.setFont(new java.awt.Font("sansserif", 1, 12)); // NOI18N
        jLabel6.setText("Not Started");
        jPanel2.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 30, -1, 20));

        jLabel7.setFont(new java.awt.Font("sansserif", 0, 10)); // NOI18N
        jLabel7.setText("Scheduling Status");
        jPanel2.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 10, -1, -1));

        jLabel8.setFont(new java.awt.Font("sansserif", 1, 12)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(51, 255, 51));
        jLabel8.setText("Open");
        jPanel2.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 30, -1, -1));

        ready.setFont(new java.awt.Font("sansserif", 1, 12)); // NOI18N
        ready.setForeground(new java.awt.Color(255, 204, 51));
        ready.setText("Ready to Schedule");
        jPanel2.add(ready, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 30, -1, -1));

        jLabel10.setFont(new java.awt.Font("sansserif", 1, 12)); // NOI18N
        jLabel10.setText("Delivery");
        jPanel2.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 30, -1, 20));

        OA.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Schedule Order", "Unschedule Order" }));
        OA.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                OAMouseClicked(evt);
            }
        });
        OA.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                OAActionPerformed(evt);
            }
        });
        jPanel2.add(OA, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 80, -1, -1));

        jButton2.setText("Search");
        jButton2.setBorder(null);
        jButton2.setFocusPainted(false);
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 20, 70, -1));

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/clm/Untitled design.png"))); // NOI18N
        jLabel4.setText("jLabel4");
        jPanel2.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 10, 90, 40));

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 840, 470));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void OAActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_OAActionPerformed

    
    
 
 int in =  OA.getSelectedIndex();

 

     if( in == 0){
     
   schedule s = new schedule(order);
   System.out.println("shceduld order");
   s.setVisible(true);
  dispose();
   
 
    
    
    
 
    
     }
     
      if( in == 1){
 
   try{

       Class.forName("com.mysql.cj.jdbc.Driver");
         String url = "jdbc:mysql://localhost:3306/clm?zeroDateTimeBehavior=CONVERT_TO_NULL";
         String user = "root";
        String password = "";
        Connection conn = DriverManager.getConnection(url,user,password);
        String sql =  "UPDATE work_order SET Schedule_Date = NULL , Time_Window = NULL WHERE WO_number = ?";
     conn.setAutoCommit(true);
       PreparedStatement pst= conn.prepareStatement(sql);
  pst.setString(1,order);
      pst.executeUpdate();
      pst.close();
      conn.close();
           System.out.println("unschedule order");
           dispose();
      user_info us = new user_info(order);
      us.setVisible(true);
           
           
          //dialog g = new dialog(order);
         // g.setVisible(true);
           
         
          
    
    
        
      
    
     
     }catch(Exception e){
     System.out.println(e);
     
     }
     
     }

        
    }//GEN-LAST:event_OAActionPerformed

    private void OAMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_OAMouseClicked
    

    }//GEN-LAST:event_OAMouseClicked

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        LocalDate currentDate = LocalDate.now();
           LocalTime currentTime = LocalTime.now();
        try{
          Class.forName("com.mysql.cj.jdbc.Driver");
         String url = "jdbc:mysql://localhost:3306/clm?zeroDateTimeBehavior=CONVERT_TO_NULL";
         String user = "root";
        String password = "";
        Connection conn = DriverManager.getConnection(url,user,password);
        String sql = "INSERT into com_log(WO_number,Logs,Date)VALUES(?,?,?)";
         PreparedStatement pst= conn.prepareStatement(sql);
         pst.setString(1, order);
         pst.setString(2, comtext.getText());
           pst.setString(3, currentDate.toString());
         pst.executeUpdate();
           DefaultTableModel model = (DefaultTableModel)logT.getModel();
           model.setRowCount(0);       
           getlog();
        }
        
        catch(Exception e){
        
        System.out.println(e);
         
        }
        
        
        
           


        
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
          search searchFrame = new search();
                searchFrame.setVisible(true);
                dispose();
               
    }//GEN-LAST:event_jButton2ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
      
        
     
      
    
              try {
            // Set FlatLaf look and feel
            UIManager.setLookAndFeel(new FlatLightLaf()); // or FlatDarkLaf() for dark theme
        } catch (UnsupportedLookAndFeelException e) {
            e.printStackTrace();
        }

        
        
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
              
                new user_info(selected).setVisible(true);
               
            }
        });
    }
      public  String order;
  public static String selected;



    // Variables declaration - do not modify//GEN-BEGIN:variables
    public static javax.swing.JLabel FirstN;
    private javax.swing.JComboBox<String> OA;
    private javax.swing.JLabel add;
    private javax.swing.JTextArea comtext;
    private javax.swing.JTabbedPane delivery;
    private javax.swing.JPanel delivery_tab;
    private javax.swing.JLabel fac;
    public static javax.swing.JLabel fulln;
    private javax.swing.JLabel hubadd;
    private javax.swing.JLabel hubn;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    public static javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JLabel loc;
    private javax.swing.JTable logT;
    private javax.swing.JLabel number;
    private javax.swing.JTable prod;
    private javax.swing.JLabel rcd;
    private javax.swing.JLabel ready;
    public static javax.swing.JLabel receive;
    private javax.swing.JLabel sd;
    private javax.swing.JLabel stat;
    private javax.swing.JLabel tw;
    // End of variables declaration//GEN-END:variables

    void sd() {
      
      System.exit(0);
        
    }
}
